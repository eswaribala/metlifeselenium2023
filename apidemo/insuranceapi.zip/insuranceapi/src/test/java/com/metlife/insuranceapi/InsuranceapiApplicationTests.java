package com.metlife.insuranceapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
