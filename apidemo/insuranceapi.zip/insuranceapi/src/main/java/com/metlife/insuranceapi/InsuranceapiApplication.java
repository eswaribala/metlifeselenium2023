package com.metlife.insuranceapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsuranceapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsuranceapiApplication.class, args);
	}

}
